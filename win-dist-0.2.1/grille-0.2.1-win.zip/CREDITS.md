# Credits

## Bundled impulse responses

Grille ships three recorded cabinet impulse responses in `Resources/irs/`. Each file is a byte-for-byte copy of the original WAV. Grille converts every bundled IR to a minimum-phase response at run time, so each one is **used in modified form (minimum-phase conversion) inside the plugin**.

### `cab-3-Brit 4x12.wav`

- Original file: `Emerald Pack 1.0/Impulses/48kHz/1_Nacho_Guacamole_48.wav`
- Pack: Jester's Emerald Pack 1.0 (4x12 cabinet with Greenback speakers; SM57 on the upper-left speaker)
- Author: Jester Dyne Productions (Bastian Karschewski)
- Source: https://www.jester-dyne-productions.com/emerald-ir-pack/
- License: CC0 1.0, https://creativecommons.org/publicdomain/zero/1.0/ (see `licenses/jesterdyne-CC0.txt`)
- File: unmodified copy. Used in modified form (minimum-phase conversion) inside the plugin.

### `cab-4-Thick 2x12.wav`

- Original file: `darwinscat-orange-ppc212v-irs/11-red-giant.wav`
- Pack: Darwin's Cat Orange PPC212V (open-back 2x12; a mix of SM57 20 mm off centre 71%, e906 7%, U87 Ai 23%)
- Author: Darwin's Cat
- Source: https://darwinscat.com/felitronics/ir/orange-ppc212v
- License: CC BY 4.0, https://creativecommons.org/licenses/by/4.0/ (see `licenses/darwinscat-LICENSE.txt`)
- File: unmodified copy. Used in modified form (minimum-phase conversion) inside the plugin.
- Attribution:

  IR: Darwin's Cat, darwinscat.com

### `cab-5-Rect 4x12.wav`

- Original file: `Jesters_Brutal_Pack_1.0/Impulses/48kHz/1_Cookie_Monster.wav`
- Pack: Jester's Brutal Pack 1.0 (4x12 cabinet; SM57 on a Vintage 30 speaker)
- Author: Jester Dyne Productions (Bastian Karschewski)
- Source: https://www.jester-dyne-productions.com/brutal-ir-pack/
- License: CC0 1.0, https://creativecommons.org/publicdomain/zero/1.0/ (see `licenses/jesterdyne-CC0.txt`)
- File: unmodified copy. Used in modified form (minimum-phase conversion) inside the plugin.

Manufacturer, speaker and microphone names above only describe how the recordings were made. No manufacturer took part in, approved or supplied them.
